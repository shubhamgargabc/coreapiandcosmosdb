﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using ToDoListDemo1.Models;

namespace ToDoListDemo1
{
    public class DocumentDBRepository<T> : IDocumentDBRepository<T> where T : class
    {

        private readonly string Endpoint = "https://coreapi-2019.documents.azure.com:443/";
        private readonly string Key = "sWlbdWNPMST1VbDevO678ld7iy8pYBFJ4MmOdFlUE12X89SdPDRXcOkCCySG2lBCIoYd5244GUyyQHiPM7dazw==";
        private readonly string DatabaseId = "ToDoList";
        private readonly string CollectionId = "Items";
        private DocumentClient client;

        public DocumentDBRepository()
        {
            this.client = new DocumentClient(new Uri(Endpoint), Key);
            CreateDatabaseIfNotExistsAsync().Wait();
            CreateCollectionIfNotExistsAsync().Wait();
        }

        public async Task<bool> CreateDatabase()
        {
            try
            {
                await client.CreateDatabaseIfNotExistsAsync(new Database { Id = DatabaseId });
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> CreateCollection()
        {
            try
            {
                await client.CreateDocumentCollectionIfNotExistsAsync
                 (UriFactory.CreateDatabaseUri(DatabaseId), new DocumentCollection { Id = CollectionId });
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<dynamic> GetItemAsync()
        {
            try
            {

                var result = await client.ReadDocumentFeedAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId),
                    new FeedOptions { MaxItemCount = 10 });

                return result;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<T> GetItemAsync(string id)
        {
            try
            {
                var document = await client.ReadDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id),
                                                    new RequestOptions { PartitionKey = new PartitionKey(id)});
                return (T)(dynamic)document;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        //public async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate)
        //{
        //    IDocumentQuery<T> query = client.CreateDocumentQuery<T>(
        //        UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId),
        //        new FeedOptions { MaxItemCount = -1 })
        //        .Where(predicate)
        //        .AsDocumentQuery();

        //    List<T> results = new List<T>();
        //    while (query.HasMoreResults)
        //    {
        //        results.AddRange(await query.ExecuteNextAsync<T>());
        //    }

        //    return results;
        //}

        public async Task<bool> CreateItemAsync(T item)
        {
            try
            {
                await client.CreateDocumentAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId), item);
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        public async Task<dynamic> UpdateItemAsync(string id, T item)
        {
            try
            {
                await client.ReplaceDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id), item);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<bool> DeleteItemAsync(string id)
        {
            try
            {
                await client.DeleteDocumentAsync(UriFactory.CreateDocumentUri(DatabaseId, CollectionId, id),
                                                    new RequestOptions { PartitionKey = new PartitionKey(id) });
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private async Task CreateDatabaseIfNotExistsAsync()
        {
            try
            {
                await client.ReadDatabaseAsync(UriFactory.CreateDatabaseUri(DatabaseId));
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private async Task CreateCollectionIfNotExistsAsync()
        {
            try
            {
                await client.ReadDocumentCollectionAsync(UriFactory.CreateDocumentCollectionUri(DatabaseId, CollectionId));
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
