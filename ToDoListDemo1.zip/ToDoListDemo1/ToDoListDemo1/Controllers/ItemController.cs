﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ToDoListDemo1.Models;

namespace ToDoListDemo1.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class ItemController : ControllerBase
    {
        IDocumentDBRepository<ToDoListDemo1.Models.Item> _adapter;
        public ItemController(IDocumentDBRepository<ToDoListDemo1.Models.Item> adapter)
        {
            _adapter = adapter;
        }

        // GET: api/Cosmos/5
        [HttpGet("createdb")]
        public async Task<IActionResult> CreateDatabase()
        {
            var result = await _adapter.CreateDatabase();
            return Ok(result);
        }

        [HttpGet("createcollection")]
        public async Task<IActionResult> CreateCollection()
        {
            var result = await _adapter.CreateCollection();
            return Ok(result);
        }

        [HttpPost("createdocument")]
        public async Task<IActionResult> CreateDocument([FromBody] Item item)
        {
            var result = await _adapter.CreateItemAsync(item);
            return Ok(result);
        }

        [HttpGet("get")]
        public async Task<IActionResult> Get()
        {
            var result = await _adapter.GetItemAsync();
            return Ok(result);
        }

        // POST: api/Cosmos
        [HttpPost("save")]
        public async Task<IActionResult> Post([FromBody] Item item)
        {
            var result = await _adapter.UpdateItemAsync(item.Id, item);
            return Ok();
        }

        //// PUT: api/Cosmos/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody] string value)
        //{
        //}

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var result = await _adapter.DeleteItemAsync(id);
            return Ok(result);
        }
    }
}