﻿using Microsoft.Azure.Documents;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace ToDoListDemo1
{
    public interface IDocumentDBRepository<T> where T : class
    {
        Task<bool> CreateItemAsync(T item);
        Task<bool> DeleteItemAsync(string id);
        Task<dynamic> GetItemAsync();
        Task<T> GetItemAsync (string id);
        //Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate);
        Task<dynamic> UpdateItemAsync(string id, T item);
        Task<bool> CreateDatabase();
        Task<bool> CreateCollection();
    }
}
